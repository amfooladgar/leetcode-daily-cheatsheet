# Architecture

## Pipeline overview

```
FETCHED
   |  src/leetcode/client.py — GraphQL call to leetcode.com/graphql
   v
NORMALIZED
   |  src/leetcode/parser.py — strip HTML, produce Problem (pydantic model)
   v
SOLVED
   |  src/claude/runner.py + prompts/claude/solve.md
   |  Claude solves from first principles; NOT shown official/community
   |  solutions (see "Why solve from scratch" below)
   v
VERIFIED
   |  src/claude/runner.py + prompts/claude/verify.md
   |  Adversarial second pass: correctness, edge cases, complexity re-check.
   |  On failure: regenerate once, then verify again. Still invalid -> STOP.
   v
TESTED
   |  src/claude/validator.py — run the solution against every official
   |  example plus a few generated edge cases (empty input, single element,
   |  max constraint boundary). A failing test is a pipeline failure.
   v
COMPRESSED
   |  prompts/claude/compress.md — fit verified content into the hard word/
   |  line limits in config/settings.yaml so the canvas never overflows.
   v
RENDERED
   |  src/rendering/compositor.py — deterministic Pillow layout: headline,
   |  problem statement, intuition, approach steps, worked example,
   |  complexity, code block, contact card. No AI-generated pixels.
   v
QA_PASSED
   |  src/rendering/compositor.py QA gate — exact 1080x1350, PNG, safe
   |  margins respected, every required section non-empty, no clipped text.
   v
UPLOADED
   |  src/storage/google_drive.py — posts/LeetCode/<year>/<month>/
   v
MANIFEST WRITTEN
      src/state/manifest.py — state/manifest.json, keyed by
      "<date>:<problem_number>" so a re-run is a no-op unless --force.
```

If a stage fails, its intermediate output (the last successfully produced
JSON/image) is kept in `output/<date>/<problem-number>/` for debugging —
nothing is silently discarded.

## Why solve from scratch instead of reading official solutions

LeetCode's own guidance is to attempt a problem independently before
consulting official/community solutions. Feeding Claude someone else's
solution and asking it to paraphrase would defeat the educational purpose
of a "never forget this" cheat sheet and risks reproducing copyrighted
write-ups. The pipeline only ever gives Claude the problem statement,
constraints, and examples — never a scraped solution.

## Why `--bare` in production

`claude -p --bare` skips auto-discovery of hooks, skills, plugins, MCP
servers, and CLAUDE.md, and forces API-key authentication instead of a
local login session. That means:

- A run behaves identically on any machine (a laptop, a GitHub Actions
  runner, a teammate's machine) because it can't accidentally pick up local
  configuration.
- Production prompts are fully specified by the files in `prompts/claude/`
  passed on the command line — nothing implicit.
- It starts faster and uses fewer tokens, since it isn't loading unrelated
  project context on every call.

CLAUDE.md still matters — it's what loads when you run interactive `claude`
sessions in this repo for development (see docs/OPERATIONS.md).

## Why no AI image model

The original design (see the ChatGPT conversation this repo grew out of)
proposed using an OpenAI image model to generate the schematic illustration
and only overlaying deterministic text/code on top. That was cut for v1:

1. **Cost.** Every daily run would call a paid image API in addition to
   Claude. A fully deterministic renderer has zero marginal image-gen cost.
2. **Reliability.** Image models are not a reliable source of truth for
   exact code, numbers, or complexity notation — exactly the content a
   "cheat sheet" cannot get wrong.
3. **Reproducibility.** A deterministic renderer produces the same output
   for the same input every time, which matters for debugging and for
   `--force` re-runs.

The `visual_plan` field is still present in `schemas/cheatsheet.schema.json`
and produced by Claude (a structured description of nodes/edges/highlight),
specifically so an AI illustration layer can be added later as an
**additive, optional** enhancement without changing the schema or any
upstream stage. See "Future: optional visual layer" below.

## Why GitHub Actions, not ChatGPT Scheduled Tasks or n8n

- GitHub Actions gives version-controlled workflow definitions, encrypted
  secrets, per-run logs, manual re-dispatch (`workflow_dispatch`), and free
  minutes for a low-frequency personal job — all in the same repo as the
  code.
- ChatGPT Scheduled Tasks cannot access files inside a ChatGPT Project, so
  prompts/config would have to live somewhere else anyway, and the surface
  is a product UI rather than a reviewable diff.
- n8n (or similar) adds a whole extra hosted service for what is, at its
  core, "run a Python script once a day."

## Why fetch LeetCode directly instead of from a personal solutions repo

The original two-repo design (a DSA solutions repo + a separate automation
repo) added a git-push-triggers-processing step that isn't needed once the
Daily Challenge itself is the trigger. Fetching directly from LeetCode's
GraphQL endpoint removes an entire repository, an entire "did my push
already get processed" state machine, and a coupling to how you personally
organize your solutions repo. The trade-off, documented here on purpose: **LeetCode
does not publish this GraphQL interface as a supported public API.** It is
the same endpoint leetcode.com's own web client uses, is widely relied on by
community tooling, and can change without notice. `src/leetcode/client.py`
isolates every LeetCode-specific assumption behind a small adapter so a
breaking change is a one-file fix, and the pipeline fails loudly (not
silently) if the response shape changes.

## Daylight saving time

GitHub Actions cron is UTC-only and America/New_York alternates between
UTC-4 (EDT) and UTC-5 (EST). `daily.yml` schedules the job at **both**
13:05 and 14:05 UTC every day; `src/main.py` checks the actual wall-clock
hour in `America/New_York` via `zoneinfo` and no-ops if it isn't the
configured `target_hour` (09:00 by default). Combined with the
idempotency manifest, this guarantees exactly one publish per day
regardless of DST.

## Failure policy

| Stage failure          | Action                                              |
|-------------------------|------------------------------------------------------|
| LeetCode fetch           | Retry (`tenacity`, 3 attempts) -> stop, no artifact  |
| Claude solve              | Retry once -> stop                                   |
| Claude verify (invalid)   | Regenerate solution once, re-verify -> stop if still invalid |
| Example/edge-case tests   | Never publish; stop                                  |
| Renderer / QA gate        | Stop (this is a bug, not a transient failure)        |
| Google Drive upload       | Retry -> stop; manifest marks `drive: false`         |

There is no image-generation or notification stage in v1, so those rows
from the original design were removed rather than left as dead policy.

## Future: optional visual layer

If you want to reintroduce an AI-generated schematic later:

1. Add `src/visuals/openai_client.py` behind the same adapter pattern as
   `src/leetcode/` and `src/storage/`.
2. Feed it only `cheatsheet["visual_plan"]` and the worked example — never
   raw code or exact text (see `prompts/future/openai-diagram.md` for the
   prompt this repo was designed around, kept as a reference and not wired
   in).
3. Composite the result as a background layer *underneath* the
   deterministic text/code layer in `src/rendering/compositor.py` — never
   let an image model render text directly.
