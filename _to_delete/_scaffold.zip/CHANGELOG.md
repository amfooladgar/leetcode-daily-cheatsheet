# Changelog

All notable changes to this project are documented here. Format loosely
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added
- Initial repository scaffold: architecture docs, versioned prompts, JSON
  schemas, pipeline module skeleton (`src/leetcode`, `src/claude`,
  `src/rendering`, `src/storage`, `src/state`), GitHub Actions workflows
  (`daily.yml`, `ci.yml`), Claude Code slash commands
  (`/solve-daily`, `/verify-daily`, `/test-pipeline`), and unit tests with
  mocked fixtures.
- Design decisions locked for v1: fetch LeetCode's Daily Challenge directly
  (no intermediate solutions repo), Claude Code performs all reasoning
  headless via `claude -p --bare`, rendering is 100% deterministic
  (Pillow, no AI image model), archival target is Google Drive only (no
  Telegram in v1 — see ARCHITECTURE.md).

### Notes
- This scaffold was generated from a design conversation (LeetCode ->
  cheat-sheet automation) and adapted to prioritize minimal recurring cost
  and reproducibility over the original hybrid AI-image-model design. See
  ARCHITECTURE.md for the full rationale on every deviation.
