import tempfile
import unittest
from pathlib import Path

import yaml

from src.rendering.compositor import render_cheatsheet
from tests.helpers import load_sample_cheatsheet_json

REPO_ROOT = Path(__file__).parent.parent


class RenderCheatsheetTests(unittest.TestCase):
    def setUp(self):
        self.config = yaml.safe_load((REPO_ROOT / "config" / "settings.yaml").read_text())
        self.tmpdir = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmpdir.cleanup)

    def test_renders_exact_canvas_size_and_format(self):
        output_path = Path(self.tmpdir.name) / "cheatsheet.png"
        result = render_cheatsheet(
            load_sample_cheatsheet_json(), self.config, output_path, contact_card_path=None
        )
        self.assertTrue(output_path.exists())
        self.assertEqual(result.width, 1080)
        self.assertEqual(result.height, 1350)
        self.assertEqual(result.format, "PNG")
        self.assertTrue(result.checks["exact_width"])
        self.assertTrue(result.checks["exact_height"])
        self.assertTrue(result.checks["correct_format"])
        self.assertTrue(result.checks["headline_present"])
        self.assertTrue(result.checks["code_present"])
        # No contact card provided -> should warn, not crash.
        self.assertTrue(any("contact card" in w for w in result.warnings))

    def test_long_content_does_not_crash_and_reports_overflow_if_any(self):
        cheatsheet = load_sample_cheatsheet_json()
        cheatsheet["intuition"] = ("This is a very long intuition sentence. " * 30).strip()
        cheatsheet["code"] = cheatsheet["code"] + "\n" + "\n".join(
            f"    # padding comment line {i} to stress vertical fit" for i in range(40)
        )
        output_path = Path(self.tmpdir.name) / "cheatsheet_long.png"
        result = render_cheatsheet(cheatsheet, self.config, output_path, contact_card_path=None)
        # Must always produce a valid PNG at the exact canvas size even
        # when content is too long -- overflow is reported as a failed
        # check for the caller to act on, never a crash or a resized canvas.
        self.assertEqual(result.width, 1080)
        self.assertEqual(result.height, 1350)


if __name__ == "__main__":
    unittest.main()
