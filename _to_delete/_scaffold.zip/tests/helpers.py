"""Fixture loaders shared by every test module.

Plain functions rather than pytest fixtures so the whole suite runs
identically under `pytest` or `python -m unittest discover`.
"""

import json
from pathlib import Path

FIXTURES = Path(__file__).parent / "fixtures"


def load_sample_problem_html() -> str:
    return (FIXTURES / "sample_problem_content.html").read_text()


def load_sample_problem_json() -> dict:
    return json.loads((FIXTURES / "sample_problem.json").read_text())


def load_sample_cheatsheet_json() -> dict:
    return json.loads((FIXTURES / "sample_cheatsheet.json").read_text())
