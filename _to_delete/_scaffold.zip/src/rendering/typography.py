"""Font loading and text-wrapping helpers shared by compositor.py and
code_renderer.py. Pure, side-effect-free (aside from an in-process font
cache) so it's trivially unit-testable without rendering a whole canvas.
"""

from __future__ import annotations

from functools import cache
from pathlib import Path

from PIL import ImageDraw, ImageFont

REPO_ROOT = Path(__file__).resolve().parent.parent.parent


@cache
def load_font(relative_path: str, size: int) -> ImageFont.FreeTypeFont:
    """Loads a font from a path relative to the repo root, cached per
    (path, size). Raises FileNotFoundError with a clear message pointing at
    config/settings.yaml if the bundled font is missing."""
    full_path = REPO_ROOT / relative_path
    if not full_path.exists():
        raise FileNotFoundError(
            f"Font not found at {full_path}. Check config/settings.yaml "
            "design.font_* paths and assets/fonts/."
        )
    return ImageFont.truetype(str(full_path), size=size)


def wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    """Greedy word-wrap. Splits on whitespace; a single word wider than
    max_width is placed on its own line rather than mid-word broken (code
    identifiers should go through code_renderer, not this)."""
    words = text.split()
    if not words:
        return []

    lines: list[str] = []
    current: list[str] = []

    for word in words:
        candidate = " ".join([*current, word])
        width = draw.textlength(candidate, font=font)
        if width <= max_width or not current:
            current.append(word)
        else:
            lines.append(" ".join(current))
            current = [word]
    if current:
        lines.append(" ".join(current))
    return lines


def block_height(num_lines: int, font: ImageFont.FreeTypeFont, line_spacing: float = 1.3) -> int:
    ascent, descent = font.getmetrics()
    line_height = int((ascent + descent) * line_spacing)
    return num_lines * line_height


def fit_paragraph(
    draw: ImageDraw.ImageDraw,
    text: str,
    font_path: str,
    max_width: int,
    max_height: int,
    max_size: int,
    min_size: int = 14,
    line_spacing: float = 1.3,
) -> tuple[ImageFont.FreeTypeFont, list[str]]:
    """Shrinks font size (max_size down to min_size) until the wrapped
    paragraph fits within max_height. Returns the font actually used and
    the wrapped lines. This is what lets the renderer stay robust to Claude
    slightly over/undershooting the word-count limits in
    prompts/claude/v1/compress.md without a human retuning pixel offsets."""
    size = max_size
    while size >= min_size:
        font = load_font(font_path, size)
        lines = wrap_text(draw, text, font, max_width)
        if block_height(len(lines), font, line_spacing) <= max_height:
            return font, lines
        size -= 1
    # Give up shrinking further; caller's QA gate will catch real overflow.
    font = load_font(font_path, min_size)
    return font, wrap_text(draw, text, font, max_width)


def fit_code_font_size(
    draw: ImageDraw.ImageDraw,
    code: str,
    font_path: str,
    max_width: int,
    max_size: int,
    min_size: int = 12,
) -> int:
    """Returns the largest font size (<= max_size, >= min_size) at which
    every line of `code` fits within max_width, so a single unusually long
    line can't blow through the safe margin. Monospace-aware but works with
    any font since it measures actual rendered width."""
    lines = code.split("\n") or [""]
    size = max_size
    while size > min_size:
        font = load_font(font_path, size)
        widest = max((draw.textlength(line, font=font) for line in lines), default=0)
        if widest <= max_width:
            return size
        size -= 1
    return min_size
