# assets/

- `contact-card.png` — **you need to add this file yourself** (not included in
  the scaffold). See docs/SETUP.md step 4 for size/format recommendations.
  Until it exists, the renderer logs a warning and produces the cheat sheet
  without a contact card overlay rather than failing.
- `fonts/` — bundled DejaVu fonts used for deterministic rendering (see
  ARCHITECTURE.md "Why no AI image model" and `assets/fonts/LICENSE-DEJAVU.txt`
  for the redistribution license). Do not delete these.
