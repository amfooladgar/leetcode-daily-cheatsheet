# leetcode-daily-cheatsheet

Every morning, this pipeline reads that day's LeetCode Daily Challenge,
solves and verifies it with Claude Code, and produces a precise,
"never-forget-it" cheat sheet — sized for a LinkedIn portrait post — that
gets archived to Google Drive.

```
LeetCode Daily Challenge
        |
        v
  GitHub Actions (09:00 America/New_York)
        |
        v
  Claude Code  --- solves, adversarially verifies, tests, compresses
        |
        v
  cheatsheet.json  (schema-validated structured content)
        |
        v
  Deterministic Pillow renderer  --- 1080x1350 PNG, 4:5, light mode
        |
        v
  Google Drive: posts/LeetCode/<year>/<month>/
```

Claude owns correctness. The renderer owns text/code fidelity (no AI image
model is in the loop — see [ARCHITECTURE.md](ARCHITECTURE.md) for why).

## Quick start

```bash
git clone <your-fork-url> leetcode-daily-cheatsheet
cd leetcode-daily-cheatsheet
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in ANTHROPIC_API_KEY etc. for local runs

# Drop your real contact card here before your first real run:
#   assets/contact-card.png  (~600x150px transparent PNG recommended)

# Try the whole pipeline end-to-end without uploading anything
python -m src.main --dry-run
```

See [docs/SETUP.md](docs/SETUP.md) for the full one-time setup (Anthropic
key, Google service account, GitHub secrets, enabling the schedule) and
[docs/OPERATIONS.md](docs/OPERATIONS.md) for how to operate it day to day
(manual reruns, reading failures, rotating keys).

## Repository layout

```
.github/workflows/   Scheduled + CI GitHub Actions
.claude/commands/    Claude Code slash commands used during development
assets/              Static assets (your contact card)
config/settings.yaml Single source of runtime configuration (no secrets)
prompts/claude/      Versioned prompts sent to Claude Code, one per stage
schemas/             JSON Schemas that gate every stage's output
src/                 Pipeline implementation (see ARCHITECTURE.md)
tests/               Unit tests with mocked network calls
docs/                SETUP.md and OPERATIONS.md
```

## Status

This is a personal automation project. See [CHANGELOG.md](CHANGELOG.md) for
what shipped in each phase, and `state/manifest.json` (created at runtime)
for the run history.
